<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
    <div>
        <input type="text" value="" name="s" id="s" style="height:20px;" />
        <input type="image" value="" src="<?php bloginfo('template_url'); ?>/images/search-button.gif" style="height:25px;" />
    </div>
</form>