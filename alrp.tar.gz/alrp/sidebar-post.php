<div id="inner-bar-post">
	<div class="widgets">
  	<?php 	if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : endif; ?>
	</div>
</div>
